
public class NumberDisplay
{
    private int MinLimit;
    private int MaxLimit;
    private int Value;

    public NumberDisplay(int minLimit, int maxLimit) throws IllegalArgumentException
    {
        this.Value=minLimit;
        this.MinLimit=minLimit;
        this.MaxLimit=maxLimit;

        if(maxLimit<minLimit)
        {
            throw new IllegalArgumentException("maxLimit is lower than minLimit");
        }

    }

    public int getValue()
    {
        return this.Value;
    }

    public void setValue( int newValue) throws IllegalArgumentException
    {

        if(newValue<this.MinLimit || newValue>this.MaxLimit)
        {
            throw new IllegalArgumentException("Time is outside of limits!");
        }

        this.Value=newValue;


    }

    public String getDisplayValue()
    {
        String numberZero = "0";
        if(this.Value<10)
        {
            return numberZero+Integer.toString(this.Value);
        }

        return Integer.toString(this.Value);
    }

    public void increment()
    {
        this.Value++;

        if(this.Value==this.MaxLimit+1)
        {
            this.Value=this.MinLimit;
        }
    }

    public boolean didWrapAround()
    {
        if(this.Value==this.MinLimit)
        {
            return true;
        }

        return false;
    }



}
