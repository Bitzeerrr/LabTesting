package io.alejandrolondono;


public enum Status {
    OPEN, CLOSED, FREEZE
}
