package io.alejandrolondono;


public enum Action {
    DEPOSIT,
    WITHDRAWL,
    TRANSFER,
    BALANCE,
    OPEN,
    CLOSE,
    LOG,
    LOGOUT
}
